package com.example.project3;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "inventory.db";
    private static final int DATABASE_VERSION = 3; // Incremented for schema/index updates

    // Existing inventory table items constants
    public static final String TABLE_NAME = "items";
    public static final String COL_ID = "id";
    public static final String COL_NAME = "name";
    public static final String COL_QUANTITY = "quantity";
    public static final String COL_PRICE = "price";

    // User Profile Table Constants
    public static final String TABLE_USERS = "users";
    public static final String COL_USER_ID = "id";
    public static final String COL_USERNAME = "username";
    public static final String COL_PASSWORD = "password";
    public static final String COL_ROLE = "role";

    // Index Names
    private static final String INDEX_ITEMS_NAME = "idx_items_name";
    private static final String INDEX_USERS_AUTH = "idx_users_auth";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create Inventory Table
        String createTable = "CREATE TABLE " + TABLE_NAME + " (" +
                COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_NAME + " TEXT, " +
                COL_QUANTITY + " INTEGER, " +
                COL_PRICE + " REAL)";
        db.execSQL(createTable);

        // Create Users Table (UNIQUE auto-indexes COL_USERNAME)
        String createUsersTable = "CREATE TABLE " + TABLE_USERS + " (" +
                COL_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_USERNAME + " TEXT UNIQUE, " +
                COL_PASSWORD + " TEXT, " +
                COL_ROLE + " TEXT)";
        db.execSQL(createUsersTable);

        // CREATE INDEXES
        createIndexes(db);
    }

    private void createIndexes(SQLiteDatabase db) {
        // Index on item name for faster searching/sorting by item name
        String createItemsNameIdx = "CREATE INDEX IF NOT EXISTS " + INDEX_ITEMS_NAME +
                " ON " + TABLE_NAME + " (" + COL_NAME + ")";
        db.execSQL(createItemsNameIdx);

        // Composite Index on username + password for instant login authentication
        String createUsersAuthIdx = "CREATE INDEX IF NOT EXISTS " + INDEX_USERS_AUTH +
                " ON " + TABLE_USERS + " (" + COL_USERNAME + ", " + COL_PASSWORD + ")";
        db.execSQL(createUsersAuthIdx);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        onCreate(db);
    }

    // Inventory operations
    public boolean insertItem(String name, int quantity, double price) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_NAME, name);
        contentValues.put(COL_QUANTITY, quantity);
        contentValues.put(COL_PRICE, price);
        long result = db.insert(TABLE_NAME, null, contentValues);
        return result != -1;
    }

    // Read-only operations for readable database
    public Cursor getAllItems() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_NAME, null);
    }

    // Register user
    public boolean registerUser(String username, String password, String role) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_USERNAME, username);
        contentValues.put(COL_PASSWORD, password); // Note: Hash passwords in production!
        contentValues.put(COL_ROLE, role);
        long result = db.insert(TABLE_USERS, null, contentValues);
        return result != -1;
    }

    // User Verification leveraging the composite index
    public Cursor verifyUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_USERS + " WHERE " +
                COL_USERNAME + "=? AND " + COL_PASSWORD + "=?", new String[]{username, password});
    }
}
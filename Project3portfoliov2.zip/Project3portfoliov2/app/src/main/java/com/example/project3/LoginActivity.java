package com.example.project3;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    EditText inputUsername, inputPassword;
    Button btnLogin, btnRegister;
    Spinner spinnerRole;
    DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        dbHelper = new DatabaseHelper(this);

        inputUsername = findViewById(R.id.login_username);
        inputPassword = findViewById(R.id.login_password);
        btnLogin = findViewById(R.id.button_login);
        btnRegister = findViewById(R.id.button_register);
        spinnerRole = findViewById(R.id.spinner_role);

        // Populate dropdown with permission roles
        String[] roles = {"Admin", "Viewer"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, roles);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerRole.setAdapter(adapter);

        // REGISTRATION BUTTON LOGIC
        btnRegister.setOnClickListener(v -> {
            String username = inputUsername.getText().toString().trim();
            String password = inputPassword.getText().toString().trim();
            String selectedRole = spinnerRole.getSelectedItem().toString();

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(LoginActivity.this, "Fill credentials to register", Toast.LENGTH_SHORT).show();
                return;
            }

            boolean success = dbHelper.registerUser(username, password, selectedRole);
            if (success) {
                Toast.makeText(LoginActivity.this, "Account Created as " + selectedRole + "!", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(LoginActivity.this, "Username taken!", Toast.LENGTH_SHORT).show();
            }
        });

        // LOGIN LOGIC
        btnLogin.setOnClickListener(v -> {
            String username = inputUsername.getText().toString().trim();
            String password = inputPassword.getText().toString().trim();

            Cursor cursor = dbHelper.verifyUser(username, password);
            if (cursor != null && cursor.moveToFirst()) {
                // Pull the stored permission string from the 'role' column (index 3)
                String userRole = cursor.getString(3);
                cursor.close();

                Toast.makeText(LoginActivity.this, "Access Granted (" + userRole + ")", Toast.LENGTH_SHORT).show();

                // Send user info over to dashboard view activity
                Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                intent.putExtra("USER_ROLE", userRole); // Pass the permission over
                startActivity(intent);
                finish();
            } else {
                Toast.makeText(LoginActivity.this, "Invalid credentials", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
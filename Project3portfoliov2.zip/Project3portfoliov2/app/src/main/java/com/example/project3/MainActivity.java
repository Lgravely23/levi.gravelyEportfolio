package com.example.project3;

import android.database.Cursor;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.appcompat.app.AppCompatActivity;

import com.journeyapps.barcodescanner.ScanContract;
import com.journeyapps.barcodescanner.ScanOptions;

public class MainActivity extends AppCompatActivity {

    DatabaseHelper dbHelper;
    EditText editName, editQuantity, editPrice;
    Button btnAdd, btnView, btnScan; // Added btnScan
    TextView textDisplay;

    // Register the scanner launcher using the modern Activity Result API
    private final ActivityResultLauncher<ScanOptions> barcodeLauncher = registerForActivityResult(
            new ScanContract(),
            result -> {
                if (result.getContents() == null) {
                    Toast.makeText(MainActivity.this, "Scanning cancelled", Toast.LENGTH_LONG).show();
                } else {
                    // Autofill the name/ID field with the scanned barcode content
                    editName.setText(result.getContents());
                    Toast.makeText(MainActivity.this, "Scanned: " + result.getContents(), Toast.LENGTH_LONG).show();
                }
            }
    );

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new DatabaseHelper(this);

        editName = findViewById(R.id.edit_name);
        editQuantity = findViewById(R.id.edit_quantity);
        editPrice = findViewById(R.id.edit_price);
        btnAdd = findViewById(R.id.button_add);
        btnView = findViewById(R.id.button_view);
        btnScan = findViewById(R.id.button_scan); // Make sure to add this ID to your XML layout
        textDisplay = findViewById(R.id.text_display);

        btnAdd.setBackgroundColor(Color.parseColor("#008080"));
        btnView.setBackgroundColor(Color.parseColor("#008080"));
        if (btnScan != null) {
            btnScan.setBackgroundColor(Color.parseColor("#008080"));
        }

        String userRole = getIntent().getStringExtra("USER_ROLE");

        if (userRole != null && userRole.equals("Viewer")) {
            // Hide input options, addition buttons, and scanner if they are just a Viewer
            btnAdd.setVisibility(View.GONE);
            editName.setVisibility(View.GONE);
            editQuantity.setVisibility(View.GONE);
            editPrice.setVisibility(View.GONE);
            if (btnScan != null) btnScan.setVisibility(View.GONE);

            Toast.makeText(this, "Logged in as View-Only Mode", Toast.LENGTH_LONG).show();
        }

        // Scanner Button Logic
        if (btnScan != null) {
            btnScan.setOnClickListener(v -> startScanning());
        }

        // Add Item Logic
        btnAdd.setOnClickListener(v -> {
            String name = editName.getText().toString().trim();
            String qtyStr = editQuantity.getText().toString().trim();
            String priceStr = editPrice.getText().toString().trim();

            if (name.isEmpty() || qtyStr.isEmpty() || priceStr.isEmpty()) {
                Toast.makeText(MainActivity.this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            int quantity = Integer.parseInt(qtyStr);
            double price = Double.parseDouble(priceStr);

            boolean inserted = dbHelper.insertItem(name, quantity, price);
            if (inserted) {
                Toast.makeText(MainActivity.this, "Item Saved!", Toast.LENGTH_SHORT).show();
                editName.setText("");
                editQuantity.setText("");
                editPrice.setText("");
                displayInventory();
            } else {
                Toast.makeText(MainActivity.this, "Insertion Failed", Toast.LENGTH_SHORT).show();
            }
        });

        // View Inventory Logic Explicit Trigger
        btnView.setOnClickListener(v -> displayInventory());

        // Initial load
        displayInventory();
    }

    // Helper method to configure and launch the scanner interface
    private void startScanning() {
        ScanOptions options = new ScanOptions();
        options.setPrompt("Volume up to turn on flash");
        options.setBeepEnabled(true);
        options.setOrientationLocked(true);
        options.setCaptureActivity(CaptureAct.class); // Explicit subclass to force portrait layout
        barcodeLauncher.launch(options);
    }


    private void displayInventory() {
        Cursor cursor = dbHelper.getAllItems();
        if (cursor.getCount() == 0) {
            textDisplay.setText(R.string.no_products_found_in_stock);
            return;
        }

        StringBuilder buffer = new StringBuilder();
        while (cursor.moveToNext()) {
            buffer.append("ID: ").append(cursor.getString(0)).append("\n");
            buffer.append("Product: ").append(cursor.getString(1)).append("\n");
            buffer.append("In Stock: ").append(cursor.getString(2)).append("\n");
            buffer.append("Price: $").append(cursor.getString(3)).append("\n\n");
        }
        textDisplay.setText(buffer.toString());
    }
}
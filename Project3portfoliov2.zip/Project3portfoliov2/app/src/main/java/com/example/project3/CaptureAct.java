package com.example.project3;

import android.app.Activity;
import com.journeyapps.barcodescanner.CaptureActivity;


public class CaptureAct extends Activity {
}
